from setuptools import setup

setup(name='pythanos',
      version='0.1',
      description='The aim of this package is to create a pipeline for data analysis and further extends to machine learning',
      url='http://github.com/umar895/pythanos',
      author='Umar',
      author_email='m.umar.hameed@outlook.com',
      license='MIT',
      packages=['pythanos'],
      zip_safe=False)
